self.__precacheManifest = [
  {
    "revision": "a131b6d0bc162a993739d9b43306a49c",
    "url": "./static/media/loader.a131b6d0.svg"
  },
  {
    "revision": "8c97409f0ee389fe75da",
    "url": "./static/js/runtime~main.8c97409f.js"
  },
  {
    "revision": "151f534e007642db2b42",
    "url": "./static/js/main.151f534e.chunk.js"
  },
  {
    "revision": "9a7322851339ca87cb6b",
    "url": "./static/js/2.9a732285.chunk.js"
  },
  {
    "revision": "151f534e007642db2b42",
    "url": "./static/css/main.e54e403b.chunk.css"
  },
  {
    "revision": "b1f2f409183d4fec3436dd68e86d4fd5",
    "url": "./index.html"
  }
];